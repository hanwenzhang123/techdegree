const HTMLBadges = prompt('How many HTML badges do you have?');
const CSSBadges = prompt('How many CSS badges do you have?');

console.log(typeof HTMLBadges, typeof CSSBadges);
