//const HTMLBadges = prompt('How many HTML badges do you have?');
//const CSSBadges = prompt('How many CSS badges do you have?');
//
//const totalBadges = +HTMLBadges + +CSSBadges;

const pi = prompt('What is Pi?');
console.log( +pi === 3.14 );