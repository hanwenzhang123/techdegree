// Collect input from a user


// Convert the input to a number


// Use Math.random() and the user's number to generate a random number


// Create a message displaying the random number

