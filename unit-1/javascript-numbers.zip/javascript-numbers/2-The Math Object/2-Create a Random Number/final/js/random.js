const dieRoll = Math.floor( Math.random() * 6 ) + 1;
console.log(`You rolled a ${dieRoll}.`);