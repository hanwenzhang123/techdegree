
var message = "Hello!";
console.log(message);
message = "Hello from JavaScript Basics";
console.log(message);