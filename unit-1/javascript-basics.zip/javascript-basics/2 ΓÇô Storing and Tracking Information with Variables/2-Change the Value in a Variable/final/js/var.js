
var message = "Hello!";
console.log(message);
message = "Hello from JavaScript Basics";
console.log(message);

var score = 0;
score += 10;
score += 5;

var bonusPts = 100;
var finalScore = score + bonusPts;
console.log(finalScore);