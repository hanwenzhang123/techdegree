
let score = 5;
score += 10;
console.log(score);