
console.log("Hello from var.js");