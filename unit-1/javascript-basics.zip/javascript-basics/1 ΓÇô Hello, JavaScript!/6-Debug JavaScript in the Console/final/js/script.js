alert("Hello, world!");
console.log("Hello from the console.");
alert("Thanks for visiting");
document.write("<h1>Welcome to my web page.</h1>");