
if () {
  console.log('The condition is true.');
} else {
  console.log('The condition is false.');
}
