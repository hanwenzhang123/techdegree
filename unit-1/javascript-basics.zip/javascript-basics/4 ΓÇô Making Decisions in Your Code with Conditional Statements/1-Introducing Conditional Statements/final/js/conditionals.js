const answer = prompt('Which planet is closest to the sun?');

if ( answer.toUpperCase() === 'MERCURY' ) {
  console.log("That's correct!");  
} else {
  console.log("Sorry, that's incorrect");
}