// 1. Declare variables and capture input.


// 2. Combine the input with other words to create a story.


// 3. Display the story as a <p> inside the <main> element.