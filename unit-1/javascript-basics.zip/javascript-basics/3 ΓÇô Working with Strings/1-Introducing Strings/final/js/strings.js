const htmlSnippet = '<h1 class="headline">My Headline</h1>';
const message = 'I\'m a programmer!';

const multiline = "Hello, students. \
Welcome to JavaScript Basics. \
I hope you learn a lot!";

console.log(multiline);