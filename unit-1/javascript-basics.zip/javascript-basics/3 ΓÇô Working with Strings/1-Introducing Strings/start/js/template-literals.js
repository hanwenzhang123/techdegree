const name = prompt('What is your name?');

const message = "Hello" + name;

console.log(message);
