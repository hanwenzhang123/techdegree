const name = prompt('What is your name?');

const message = `Hello, ${name}. Welcome to my music site. I'm happy that you came by to visit, ${name}. Please come again and listen to more music!`;

console.log(message);
