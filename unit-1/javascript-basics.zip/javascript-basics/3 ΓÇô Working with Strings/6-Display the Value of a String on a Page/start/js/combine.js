const name = prompt("What is your name?");
let message = "Hello, " + name + ". Welcome to my music site. ";
message += "I'm so happy that you came by to visit, ";
message += name;
message += ". Feel free to come again and listen to more music!";

console.log(message);