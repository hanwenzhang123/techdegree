const name = prompt('What is your name?');
console.log(name);