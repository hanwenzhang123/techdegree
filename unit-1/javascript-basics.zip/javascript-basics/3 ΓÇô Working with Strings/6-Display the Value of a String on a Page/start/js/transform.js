const passphrase = 'I Have Spoken';
console.log( passphrase.toUpperCase() );
console.log(passphrase);