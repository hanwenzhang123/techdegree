/**
 * Returns a random number between two numbers.
 *
 * @param {number} lower - The lowest number value.
 * @param {number} upper - The highest number value.
 * @return {number} The random number value.
 */

Math.floor(Math.random() * (6 - 1 + 1)) + 1;

// Call the function and pass it different values


