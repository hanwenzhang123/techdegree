function alertRandom() {
  const randomNumber = Math.floor( Math.random() * 6 ) + 1;
  alert(randomNumber);
}

alertRandom();
alertRandom();
alertRandom();
alertRandom();