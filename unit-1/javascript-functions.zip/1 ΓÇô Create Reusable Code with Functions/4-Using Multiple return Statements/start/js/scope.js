function greeting() {
  let person = 'Meg';
  alert(`Hi, ${person}!`);
}