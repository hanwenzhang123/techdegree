const randomNumber = Math.floor( Math.random() * 6 ) + 1;

