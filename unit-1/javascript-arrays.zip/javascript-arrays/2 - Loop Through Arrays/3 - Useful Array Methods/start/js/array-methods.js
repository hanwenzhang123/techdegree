const daysInWeek = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday'
];

const fruit = [
  'apple', 
  'orange', 
  'grapefruit', 
  'pineapple', 
  'strawberry'
];
















