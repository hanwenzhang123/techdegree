const instruments = ['piano', 'drums', 'trumpet'];
instruments.push( 'guitar', 'violin', 'triangle' );
instruments.unshift( 'cowbell', 'tuba' );