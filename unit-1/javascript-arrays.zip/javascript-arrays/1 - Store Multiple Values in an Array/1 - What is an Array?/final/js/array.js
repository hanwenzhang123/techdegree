const shoppingList = [
  'Mercury',
  'Venus',
  'Earth',
  'Mars'
];