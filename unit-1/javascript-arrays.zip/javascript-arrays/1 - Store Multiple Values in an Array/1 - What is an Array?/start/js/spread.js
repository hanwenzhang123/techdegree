const middle = ['lettuce', 'cheese', 'patty'];
const burger = ['top bun', 'bottom bun'];