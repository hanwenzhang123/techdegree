const person = {
  name: 'Edward',
  city: 'New York',
  age: 37,
  isStudent: true,
  skills: ['JavaScript', 'HTML', 'CSS']
};

const message = `Hi, I'm ${person.name}. I live in ${person.city}.`;
console.log(message);