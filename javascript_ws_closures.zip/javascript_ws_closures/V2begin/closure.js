var birds = 3;

function dogHouse() {
	var dogs = 8;
}
