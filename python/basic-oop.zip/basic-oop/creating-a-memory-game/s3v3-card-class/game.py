# class Game
    # grid size
    # card options - words to use in the game
    # columns - rows can be generated
    # list of locations in the grid
    # Methods
        # create a list of card instances
        # create a grid
        # check for matches
        # check for a win
        # make sure the player’s location input is a real 
        # run the game


# dunder main
    # create an instance
    # call start game