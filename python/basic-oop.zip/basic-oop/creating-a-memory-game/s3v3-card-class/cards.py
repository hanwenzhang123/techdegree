# class Card
    # hold a card
    # know whether it's been matched or not
    # hold the card's location
    # know if two cards are equal or not
    # be able to print out the card