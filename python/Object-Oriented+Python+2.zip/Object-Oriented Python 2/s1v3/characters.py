class Thief:
    sneaky = True
  