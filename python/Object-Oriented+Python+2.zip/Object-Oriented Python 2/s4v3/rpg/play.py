from thieves import Thief

kenneth = Thief(name="Kenneth", sneaky=False)
print(kenneth)
print(kenneth.sneaky)
print(kenneth.agile)
print(kenneth.hide(8))