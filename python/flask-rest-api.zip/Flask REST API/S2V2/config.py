DEBUG = True
HOST = '0.0.0.0'
PORT = 8000
SECRET_KEY = 'OAUOB#@auoeht,52au,ouoI<.%2242uoaIoiua,biostiho'