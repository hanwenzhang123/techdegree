var isTrue = true;

//if(isTrue) {
//	console.log('yes');
//} else {
//	console.log('no');
//}

var yesOrNo = isTrue ? 'yes' : 'no';

console.log(yesOrNo);