var isTrue = true;

if(isTrue) {
	console.log('yes');
} else {
	console.log('no');
}