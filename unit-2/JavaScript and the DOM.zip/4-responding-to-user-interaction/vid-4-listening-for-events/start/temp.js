
window.setTimeout((something) => {
  console.log(something);
}, 3000, 'Greetings, everyone!');