# Debugging JavaScript in the Browser
This is the finished project from DOM Scripting By Example, but with five bugs.

We'll fix them using Chrome DevTools.