class Token {
    
}