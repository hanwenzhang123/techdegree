### Simple Sum

Define a function `simpleSum` that takes two numbers and returns the sum of
those numbers.

```javascript
simpleSum(10, 20); // => 30
simpleSum(5, 10); // => 15
```
