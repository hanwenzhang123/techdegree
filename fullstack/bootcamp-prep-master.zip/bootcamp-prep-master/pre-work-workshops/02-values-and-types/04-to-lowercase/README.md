### To Lowercase

Create a String by surrounding characters with an apostrophe or quotation marks.  Call the toLowerCase() method
on the string.

EX: "FULLSTACK ACADEMY".toLowerCase()
OUTPUT: "fullstack academy";
