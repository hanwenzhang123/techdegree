### Current Year

Create an Arithmetic Expression that uses three mathematical operators (+,-,/,*) that returns the date
of the current year.

EX: 2000 + 18 - 2 * 1;
