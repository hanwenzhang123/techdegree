### To Uppercase

Create a String by surrounding characters with an apostrophe or quotation marks.
Call the toUpperCase() method on the string.

EX: "apples".toUpperCase()
OUTPUT: "APPLES"
