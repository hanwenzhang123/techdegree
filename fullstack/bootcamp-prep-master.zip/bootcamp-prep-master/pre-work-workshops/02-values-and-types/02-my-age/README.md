### My Age

Create an Arithmetic Expression that uses four mathematical operators (+,-,/,*)
that returns your current age.

EX: (9+1)*6/2-1;
