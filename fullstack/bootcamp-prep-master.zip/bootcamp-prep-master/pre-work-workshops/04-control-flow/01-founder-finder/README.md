### Founder Finder

Given a string value name, set the found variable to:
  - true if the name is equal to 'David'
  - true if the name is equal to 'Nimit'
  - false if the name is equal to 'Someone else'
