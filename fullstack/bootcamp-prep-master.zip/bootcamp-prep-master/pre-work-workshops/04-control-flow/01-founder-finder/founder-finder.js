let name = 'David';
// let name = 'Nimit';
// let name = 'Someone else';

let found;

// YOUR CODE BELOW
