### Truth Teller

Given two boolean values boolean1 and boolean2, set the result variable to:
  - 'both' if both boolean1 and boolean2 are true
  - 'one' if only one of boolean1 and boolean2 are true
  - 'none' if neither value is true

