console.log('hello world!');

// this is a comment!

/*
  this is also a comment!
  it spans multiple lines!
*/
