console.log(10 + 20);
