let happyNum = 1000;

// YOUR CODE BELOW
