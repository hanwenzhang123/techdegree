describe("happyNum", function() {

  it("should be equal to 5", function() {
    expect(happyNum).toEqual(5);
  });

});
