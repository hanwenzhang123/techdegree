### Take the Shortcut

Given a starting value assigned to the happyNum variable, use at least three of
the following operators to reassign the value in happyNum until it is equal to
5:

  - +=
  - -=
  - *=
  - /=
  - ++
  - --
