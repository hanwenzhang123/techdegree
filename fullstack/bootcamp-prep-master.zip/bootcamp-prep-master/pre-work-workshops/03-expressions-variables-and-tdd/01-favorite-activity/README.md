### Favorite Activity

Create a variable called favoriteActivity. Assign the value 'coding' to favoriteActivity.
