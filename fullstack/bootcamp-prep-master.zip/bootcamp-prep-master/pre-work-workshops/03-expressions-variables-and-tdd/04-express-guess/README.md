### Express Guess

 Look at the expression below. Guess what the result of the expression will be,
 and store your guess in a variable called myGuess.

 Expression: 20 * (50 / (5 * 2) + 15)
