### First Sum

Given three numbers, assign the sum of all three numbers to a variable called
myFirstSum.
