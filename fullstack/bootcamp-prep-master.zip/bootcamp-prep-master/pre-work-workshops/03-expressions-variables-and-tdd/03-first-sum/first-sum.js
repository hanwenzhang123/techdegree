let num1 = 854;
let num2 = 385;
let num3 = 779;

// YOUR CODE BELOW
