### Variable Assignment

Create a variable called myFirstName. Assign myFirstName a string value that
represents your first name.

Create another variable called myFavoriteNum. Assign myFavoriteNum a number
value that represents your favorite number!

Create a third variable, havingFun. Assign havingFun a boolean value that
reflects whether or not you're having fun!
