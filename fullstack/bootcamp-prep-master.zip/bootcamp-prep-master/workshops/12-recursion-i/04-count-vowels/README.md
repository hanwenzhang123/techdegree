### Count Vowels

Write a function, countVowels, that accepts a string and returns the number of
vowels in that string. Use recursion.

```javascript
countVowels('Four score and seven years'); // => 9
```
