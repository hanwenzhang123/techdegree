describe('oddJob', () => {

  it('returns true', () => {
    let returnedValue = oddJob();
    expect(returnedValue).toEqual(true);
  });

});


describe('goldFinger', () => {

  it('returns true', () => {
    let returnedValue = goldFinger();
    expect(returnedValue).toEqual(true);
  });

});


describe('scaramanga', () => {

  it('returns true', () => {
    let returnedValue = scaramanga();
    expect(returnedValue).toEqual(true);
  });

});


describe('drNo', () => {

  it('returns true', () => {
    let returnedValue = drNo();
    expect(returnedValue).toEqual(true);
  });

});


describe('jaws', () => {

  it('returns true', () => {
    let returnedValue = jaws();
    expect(returnedValue).toEqual(true);
  });

});

describe('elChiffre', () => {

  it('returns true', () => {
    let returnedValue = elChiffre();
    expect(returnedValue).toEqual(true);
  });

});
