let sum = 0;

function sumThingsWrong(num1, num2) {
  sum += num1;
  sum += num2;

  return sum;
}
