### Sum Things Wrong

The function `sumThingsWrong` is failing some of its tests. Why? Fix the code so
it works.
