### Scope Koans

All of the tests for scope-koans.js are failing. Following the restrictions for
each function in scope-koans.js, fix the code so every test passes.

For all functions, you may not:
  1. Edit the line initially declaring each test message (e.g., testOneMessage)
  2. Edit any code on the same line as the return keyword.

It may be helpful to look at the values passed into these functions in
scope-koans.spec.js!
