let counter = 0;

// YOUR CODE BELOW
