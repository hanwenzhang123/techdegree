### Array Sum

Write a function, arraySum, that accepts an array of numbers and returns the sum
of all the numbers in the array (no matter how nested!).

```javascript
arraySum([1, [2, 3, [4]]]) // => 10
```
