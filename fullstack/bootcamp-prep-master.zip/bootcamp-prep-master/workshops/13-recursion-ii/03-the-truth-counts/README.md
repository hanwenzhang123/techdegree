### The Truth Counts

Write a function, theTruthCounts, that accepts a multi-dimensional array of
values. theTruthCounts should return the count of all truthy values inside the
multidimesional array.

```javascript
theTruthCounts([0, [true, ['yes']]]); // => 2
```
