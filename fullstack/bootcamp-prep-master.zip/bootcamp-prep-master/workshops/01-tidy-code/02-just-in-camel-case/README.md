### Just in Camel Case

The code in just-in-camel-case.js also works! But it it looks like the well-
meaning developer who wrote it didn't use camel case when defining the
variables!

Fix this, but don't forget to make sure all of the tests are still
passing when you're done.
