// YOUR CODE BELOW
function getMax(f, s, a) {if (f > s) {if (f > a) {return f;} return a;} else if (s > a) {return s;}else {return a;}}
