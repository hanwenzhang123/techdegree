### Get Max

The code in get-max.js also works! But it's a complete mess. Using proper
indentation, and better variable names, refactor this code so that a person
can understand what it does!

Make sure it's still passing all of its tests when you're done!
