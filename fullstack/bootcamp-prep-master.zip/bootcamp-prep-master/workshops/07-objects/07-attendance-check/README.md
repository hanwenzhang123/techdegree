### Attendance Check

Define a function, `attendanceCheck`, that accepts a day of the week as a string.

Using the globally-defined classRoom array, `attendanceCheck` should return a
new array with only the names of the students present on the inputted day of
the week.

```javascript

classCheck('Monday'); // => ['Marnie', 'Shoshanna']

classCheck('Wednesday'); // => ['Marnie', 'Lena']
```
