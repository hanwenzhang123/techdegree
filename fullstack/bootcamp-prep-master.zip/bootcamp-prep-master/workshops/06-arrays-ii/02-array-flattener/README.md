### Array Flattener

Define a function, `arrayFlattener`, that accepts a two-dimensional array as an
argument.

`arrayFlattener` should return a new, one-dimensional array.

```javascript
arrayFlattener([1,[2, 3], 4]); // => [1, 2, 3, 4]
```
