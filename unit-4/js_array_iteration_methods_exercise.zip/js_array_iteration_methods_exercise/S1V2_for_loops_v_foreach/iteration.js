const fruits = ['apple', 'pear', 'cherry'];
