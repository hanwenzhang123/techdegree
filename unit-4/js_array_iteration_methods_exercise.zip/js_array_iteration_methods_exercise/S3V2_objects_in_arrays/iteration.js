const users = [
  {name: 'Samir'},
  {name: 'Angela'},
  {name: 'Beatrice'}
];
