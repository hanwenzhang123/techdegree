const ernie = {
    animal: 'dog',
    age: '1',
    breed: 'pug',
    bark: function(){
        console.log('Woof!');
    }
}

const vera = {
    animal: 'dog',
    age: 8,
    breed: 'Border Collie',
    bark: function(){
        console.log('Woof!');
    }
}

const scofield = {
    animal: 'dog',
    age: 6,
    breed: 'Doberman',
    bark: function(){
        console.log('Woof!');
    }
}

const edel = {
    animal: 'dog',
    age: 7,
    breed: 'German Shorthaired Pointer',
    bark: function(){
        console.log('Woof!');
    }
}













