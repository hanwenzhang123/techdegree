class Pet {
  constructor() {

  }
}