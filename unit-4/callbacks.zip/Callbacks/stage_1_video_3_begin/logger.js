const person = {
    name: 'Andrew Chalkley',
    role: 'JavaScript Teacher'
}

function logTeacher(teacher) {
    console.log(`${teacher.name} - ${teacher.role}`);
}

logTeacher(person);
