function sayHello() {
    console.log('Hello');
}